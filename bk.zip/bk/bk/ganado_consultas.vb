﻿Imports System.Data
Imports System.Data.OleDb
Imports System.IO
Public Class ganado_consultas
    Dim connection19 As New OleDb.OleDbConnection
    Dim command19 As New OleDb.OleDbCommand
    Dim adapter19 As New OleDbDataAdapter
    Dim find19 As New DataSet
    Dim dset19 As New DataSet
    Private Sub ganado_consultas_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        conn.ConnectionString = "server=localhost;user id=root;port=3306;password=;database=ganadera"
        'Try
        ' connection19.ConnectionString = ("Provider=Microsoft.ACE.OLEDB.12.0; Data Source=" & Application.StartupPath & "\ganadera.accdb")
        'connection19.Open()
        'MsgBox("conexion exitosa", vbInformation, "conectado")
        'Catch ex As Exception
        'MsgBox("error al conectar", vbInformation, "error" & ex.Message)
        'End Try
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click

        sql = "SELECT * FROM ganado WHERE no_id ='" & TextBox1.Text & "'"

        ds.Reset()
        connect()
        dr.Close()

        sda.SelectCommand = cmd
        sda.Fill(ds)
        DataGridView1.DataSource = ds.Tables(0)

        'Dim search19 As String
        'Dim list19 As Byte
        'If TextBox1.Text <> "" Then
        'search19 = "select no_de_id, edad, raza, sexo, peso from ganado where no_de_id ='" & TextBox1.Text & "'"
        'adapter19 = New OleDbDataAdapter(search19, connection19)
        'find19 = New DataSet
        'adapter19.Fill(find19, "ganado")
        'list19 = find19.Tables("ganado").Rows.Count
        'If list19 <> 0 Then
        'TextBox1.Text = find19.Tables("ganado").Rows(0).Item("numero")
        'TextBox2.Text = find19.Tables("ganado").Rows(0).Item("edad")
        'TextBox3.Text = find19.Tables("ganado").Rows(0).Item("raza")
        'ComboBox1.Text = find19.Tables("ganado").Rows(0).Item("sexo")
        'TextBox4.Text = find19.Tables("ganado").Rows(0).Item("fierro")
        'DataGridView1.DataSource = find19.Tables(0)
        'Else
        MsgBox("EL REGISTRO NO EXISTE EN LA BASE DE DATOS", vbCritical, "ATENCION!")
        '    End If
        'End If
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Me.Close()
    End Sub

    Private Sub TextBox1_KeyPress(sender As Object, e As KeyPressEventArgs) Handles TextBox1.KeyPress
        If (Char.IsLetter(e.KeyChar)) Then
            e.Handled = True
        ElseIf (Char.IsSymbol(e.KeyChar)) Then
            e.Handled = True
        ElseIf (Char.IsPunctuation(e.KeyChar)) Then
            e.Handled = True
        ElseIf (Char.IsNumber(e.KeyChar)) Then
            e.Handled = False
            TextBox1.MaxLength = 10
        ElseIf Asc(e.KeyChar) = 13 Then
            TextBox2.Focus()
        End If
    End Sub

    Private Sub TextBox2_KeyPress(sender As Object, e As KeyPressEventArgs) Handles TextBox2.KeyPress
        If (Char.IsLetter(e.KeyChar)) Then
            e.Handled = True
        ElseIf (Char.IsSymbol(e.KeyChar)) Then
            e.Handled = True
        ElseIf (Char.IsPunctuation(e.KeyChar)) Then
            e.Handled = True
        ElseIf (Char.IsNumber(e.KeyChar)) Then
            e.Handled = False
            TextBox1.MaxLength = 4
        ElseIf Asc(e.KeyChar) = 13 Then
            TextBox3.Focus()
        End If
    End Sub

    Private Sub TextBox3_KeyPress(sender As Object, e As KeyPressEventArgs) Handles TextBox3.KeyPress
        If (Char.IsLetter(e.KeyChar)) Then
            e.Handled = False
            TextBox1.MaxLength = 10
        ElseIf (Char.IsSymbol(e.KeyChar)) Then
            e.Handled = True
        ElseIf (Char.IsPunctuation(e.KeyChar)) Then
            e.Handled = True
        ElseIf (Char.IsNumber(e.KeyChar)) Then
            e.Handled = True
        ElseIf Asc(e.KeyChar) = 13 Then
            TextBox4.Focus()
        End If
    End Sub

    Private Sub TextBox4_KeyPress(sender As Object, e As KeyPressEventArgs) Handles TextBox4.KeyPress
        If (Char.IsLetter(e.KeyChar)) Then
            e.Handled = False
            TextBox1.MaxLength = 7
        ElseIf (Char.IsSymbol(e.KeyChar)) Then
            e.Handled = True
        ElseIf (Char.IsPunctuation(e.KeyChar)) Then
            e.Handled = True
        ElseIf (Char.IsNumber(e.KeyChar)) Then
            e.Handled = True
        ElseIf Asc(e.KeyChar) = 13 Then
            TextBox1.Focus()
        End If
    End Sub
End Class
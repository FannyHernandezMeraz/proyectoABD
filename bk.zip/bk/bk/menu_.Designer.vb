﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class menu_
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(menu_))
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.ArchivoToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SalirToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.NacimientosToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AltasToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.BajasToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ConsultasToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.DecesosToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AltasToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.BajasToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ConsultasToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.VentasToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AltasToolStripMenuItem2 = New System.Windows.Forms.ToolStripMenuItem()
        Me.BajasToolStripMenuItem2 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ConsultasToolStripMenuItem2 = New System.Windows.Forms.ToolStripMenuItem()
        Me.SuplementosToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AltasToolStripMenuItem3 = New System.Windows.Forms.ToolStripMenuItem()
        Me.BajasToolStripMenuItem3 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ConsultasToolStripMenuItem3 = New System.Windows.Forms.ToolStripMenuItem()
        Me.MenuStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'MenuStrip1
        '
        Me.MenuStrip1.BackColor = System.Drawing.Color.Transparent
        Me.MenuStrip1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.MenuStrip1.GripMargin = New System.Windows.Forms.Padding(2, 2, 0, 2)
        Me.MenuStrip1.ImageScalingSize = New System.Drawing.Size(24, 24)
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ArchivoToolStripMenuItem, Me.NacimientosToolStripMenuItem, Me.DecesosToolStripMenuItem, Me.VentasToolStripMenuItem, Me.SuplementosToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(1054, 37)
        Me.MenuStrip1.TabIndex = 0
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'ArchivoToolStripMenuItem
        '
        Me.ArchivoToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.SalirToolStripMenuItem})
        Me.ArchivoToolStripMenuItem.Name = "ArchivoToolStripMenuItem"
        Me.ArchivoToolStripMenuItem.Size = New System.Drawing.Size(113, 33)
        Me.ArchivoToolStripMenuItem.Text = "archivo"
        '
        'SalirToolStripMenuItem
        '
        Me.SalirToolStripMenuItem.Name = "SalirToolStripMenuItem"
        Me.SalirToolStripMenuItem.Size = New System.Drawing.Size(270, 38)
        Me.SalirToolStripMenuItem.Text = "salir"
        '
        'NacimientosToolStripMenuItem
        '
        Me.NacimientosToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.AltasToolStripMenuItem, Me.BajasToolStripMenuItem, Me.ConsultasToolStripMenuItem})
        Me.NacimientosToolStripMenuItem.Name = "NacimientosToolStripMenuItem"
        Me.NacimientosToolStripMenuItem.Size = New System.Drawing.Size(169, 33)
        Me.NacimientosToolStripMenuItem.Text = "nacimientos"
        '
        'AltasToolStripMenuItem
        '
        Me.AltasToolStripMenuItem.Name = "AltasToolStripMenuItem"
        Me.AltasToolStripMenuItem.Size = New System.Drawing.Size(270, 38)
        Me.AltasToolStripMenuItem.Text = "altas"
        '
        'BajasToolStripMenuItem
        '
        Me.BajasToolStripMenuItem.Name = "BajasToolStripMenuItem"
        Me.BajasToolStripMenuItem.Size = New System.Drawing.Size(270, 38)
        Me.BajasToolStripMenuItem.Text = "bajas"
        '
        'ConsultasToolStripMenuItem
        '
        Me.ConsultasToolStripMenuItem.Name = "ConsultasToolStripMenuItem"
        Me.ConsultasToolStripMenuItem.Size = New System.Drawing.Size(270, 38)
        Me.ConsultasToolStripMenuItem.Text = "consultas"
        '
        'DecesosToolStripMenuItem
        '
        Me.DecesosToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.AltasToolStripMenuItem1, Me.BajasToolStripMenuItem1, Me.ConsultasToolStripMenuItem1})
        Me.DecesosToolStripMenuItem.Name = "DecesosToolStripMenuItem"
        Me.DecesosToolStripMenuItem.Size = New System.Drawing.Size(128, 33)
        Me.DecesosToolStripMenuItem.Text = "decesos"
        '
        'AltasToolStripMenuItem1
        '
        Me.AltasToolStripMenuItem1.Name = "AltasToolStripMenuItem1"
        Me.AltasToolStripMenuItem1.Size = New System.Drawing.Size(270, 38)
        Me.AltasToolStripMenuItem1.Text = "altas"
        '
        'BajasToolStripMenuItem1
        '
        Me.BajasToolStripMenuItem1.Name = "BajasToolStripMenuItem1"
        Me.BajasToolStripMenuItem1.Size = New System.Drawing.Size(270, 38)
        Me.BajasToolStripMenuItem1.Text = "bajas"
        '
        'ConsultasToolStripMenuItem1
        '
        Me.ConsultasToolStripMenuItem1.Name = "ConsultasToolStripMenuItem1"
        Me.ConsultasToolStripMenuItem1.Size = New System.Drawing.Size(270, 38)
        Me.ConsultasToolStripMenuItem1.Text = "consultas"
        '
        'VentasToolStripMenuItem
        '
        Me.VentasToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.AltasToolStripMenuItem2, Me.BajasToolStripMenuItem2, Me.ConsultasToolStripMenuItem2})
        Me.VentasToolStripMenuItem.Name = "VentasToolStripMenuItem"
        Me.VentasToolStripMenuItem.Size = New System.Drawing.Size(104, 33)
        Me.VentasToolStripMenuItem.Text = "ventas"
        '
        'AltasToolStripMenuItem2
        '
        Me.AltasToolStripMenuItem2.Name = "AltasToolStripMenuItem2"
        Me.AltasToolStripMenuItem2.Size = New System.Drawing.Size(270, 38)
        Me.AltasToolStripMenuItem2.Text = "altas"
        '
        'BajasToolStripMenuItem2
        '
        Me.BajasToolStripMenuItem2.Name = "BajasToolStripMenuItem2"
        Me.BajasToolStripMenuItem2.Size = New System.Drawing.Size(270, 38)
        Me.BajasToolStripMenuItem2.Text = "bajas"
        '
        'ConsultasToolStripMenuItem2
        '
        Me.ConsultasToolStripMenuItem2.Name = "ConsultasToolStripMenuItem2"
        Me.ConsultasToolStripMenuItem2.Size = New System.Drawing.Size(270, 38)
        Me.ConsultasToolStripMenuItem2.Text = "consultas"
        '
        'SuplementosToolStripMenuItem
        '
        Me.SuplementosToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.AltasToolStripMenuItem3, Me.BajasToolStripMenuItem3, Me.ConsultasToolStripMenuItem3})
        Me.SuplementosToolStripMenuItem.Name = "SuplementosToolStripMenuItem"
        Me.SuplementosToolStripMenuItem.Size = New System.Drawing.Size(178, 33)
        Me.SuplementosToolStripMenuItem.Text = "suplementos"
        '
        'AltasToolStripMenuItem3
        '
        Me.AltasToolStripMenuItem3.Name = "AltasToolStripMenuItem3"
        Me.AltasToolStripMenuItem3.Size = New System.Drawing.Size(270, 38)
        Me.AltasToolStripMenuItem3.Text = "altas"
        '
        'BajasToolStripMenuItem3
        '
        Me.BajasToolStripMenuItem3.Name = "BajasToolStripMenuItem3"
        Me.BajasToolStripMenuItem3.Size = New System.Drawing.Size(270, 38)
        Me.BajasToolStripMenuItem3.Text = "bajas"
        '
        'ConsultasToolStripMenuItem3
        '
        Me.ConsultasToolStripMenuItem3.Name = "ConsultasToolStripMenuItem3"
        Me.ConsultasToolStripMenuItem3.Size = New System.Drawing.Size(270, 38)
        Me.ConsultasToolStripMenuItem3.Text = "consultas"
        '
        'menu_
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(15.0!, 29.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ClientSize = New System.Drawing.Size(1054, 582)
        Me.Controls.Add(Me.MenuStrip1)
        Me.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MainMenuStrip = Me.MenuStrip1
        Me.Margin = New System.Windows.Forms.Padding(4)
        Me.Name = "menu_"
        Me.Text = "menu_"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents MenuStrip1 As System.Windows.Forms.MenuStrip
    Friend WithEvents ArchivoToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SalirToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents NacimientosToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents AltasToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents BajasToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ConsultasToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents DecesosToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents AltasToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents BajasToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ConsultasToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents VentasToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents AltasToolStripMenuItem2 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents BajasToolStripMenuItem2 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ConsultasToolStripMenuItem2 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SuplementosToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents AltasToolStripMenuItem3 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents BajasToolStripMenuItem3 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ConsultasToolStripMenuItem3 As System.Windows.Forms.ToolStripMenuItem
End Class

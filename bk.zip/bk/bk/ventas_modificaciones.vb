﻿Imports System.Data
Imports System.Data.OleDb
Imports System.IO
Public Class ventas_modificaciones
    Dim connection12 As New OleDb.OleDbConnection
    Dim command12 As New OleDb.OleDbCommand
    Dim adapter12 As New OleDbDataAdapter
    Dim find12 As New DataSet
    Dim dset12 As New DataSet
    Private Sub ventas_modificaciones_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        conn.ConnectionString = "server=localhost;user id=root;port=3306;password=;database=ganadera"
        'Try
        'connection12.ConnectionString = ("Provider=Microsoft.ACE.OLEDB.12.0; Data Source=" & Application.StartupPath & "\ganadera.accdb")
        'connection12.Open()
        'MsgBox("conexion exitosa", vbInformation, "conectado")
        'Catch ex As Exception
        'MsgBox("error al conectar", vbInformation, "error" & ex.Message)
        'End Try
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        'Dim update12 As String
        'update12 = "update ventas set edad='" & TextBox2.Text & "', sexo='" & ComboBox1.Text & "', peso='" & TextBox3.Text & "' where numero='" & TextBox1.Text & "'"
        'command12 = New OleDbCommand(update12, connection12)
        'command12.ExecuteNonQuery()

        sql = "UPDATE ventas SET edad=@edad, sexo=@sexo, peso=@peso WHERE no_venta='" & TextBox1.Text & "'"

        With cmd
            .Parameters.Clear()
            .Parameters.AddWithValue("@sexo", ComboBox1.Text)
            .Parameters.AddWithValue("@peso", TextBox3.Text)
            .Parameters.AddWithValue("@edad", TextBox2.Text)

        End With

        connect()

        conn.Close()

        MsgBox("REGISTRO ACTUALIZADO", vbInformation, "CORRECTO")
        TextBox1.Text = ""
        ComboBox1.Text = ""
        TextBox2.Text = ""
        TextBox3.Text = ""
        TextBox1.Focus()
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Me.Close()
    End Sub

    Private Sub TextBox1_KeyPress(sender As Object, e As KeyPressEventArgs) Handles TextBox1.KeyPress
        If (Char.IsLetter(e.KeyChar)) Then
            e.Handled = True
        ElseIf (Char.IsSymbol(e.KeyChar)) Then
            e.Handled = True
        ElseIf (Char.IsPunctuation(e.KeyChar)) Then
            e.Handled = True
        ElseIf (Char.IsNumber(e.KeyChar)) Then
            e.Handled = False
            TextBox1.MaxLength = 6
        ElseIf Asc(e.KeyChar) = 13 Then
            TextBox2.Focus()
        End If
    End Sub

    Private Sub TextBox2_KeyPress(sender As Object, e As KeyPressEventArgs) Handles TextBox2.KeyPress
        If (Char.IsLetter(e.KeyChar)) Then
            e.Handled = True
        ElseIf (Char.IsSymbol(e.KeyChar)) Then
            e.Handled = True
        ElseIf (Char.IsPunctuation(e.KeyChar)) Then
            e.Handled = True
        ElseIf (Char.IsNumber(e.KeyChar)) Then
            e.Handled = False
            TextBox1.MaxLength = 4
        ElseIf Asc(e.KeyChar) = 13 Then
            TextBox3.Focus()
        End If
    End Sub

    Private Sub TextBox3_KeyPress(sender As Object, e As KeyPressEventArgs) Handles TextBox3.KeyPress
        If (Char.IsLetter(e.KeyChar)) Then
            e.Handled = True
        ElseIf (Char.IsSymbol(e.KeyChar)) Then
            e.Handled = True
        ElseIf (Char.IsPunctuation(e.KeyChar)) Then
            e.Handled = False
        ElseIf (Char.IsNumber(e.KeyChar)) Then
            e.Handled = False
            TextBox1.MaxLength = 6
        ElseIf Asc(e.KeyChar) = 13 Then
            TextBox1.Focus()
        End If
    End Sub
End Class
﻿Imports System.Data
Imports System.Data.OleDb
Imports System.IO
Public Class decesos_consultas
    Dim connection7 As New OleDb.OleDbConnection
    Dim command7 As New OleDb.OleDbCommand
    Dim adapter7 As New OleDbDataAdapter
    Dim find7 As New DataSet
    Dim dset7 As New DataSet
    Private Sub decesos_consultas_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        conn.ConnectionString = "server=localhost;user id=root;port=3306;password=;database=ganadera"
        ' Try
        'connection7.ConnectionString = ("Provider=Microsoft.ACE.OLEDB.12.0; Data Source=" & Application.StartupPath & "\ganadera.accdb")
        'connection7.Open()
        'MsgBox("conexion exitosa", vbInformation, "conectado")
        'Catch ex As Exception
        'MsgBox("error al conectar", vbInformation, "error" & ex.Message)
        'End Try
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click

        sql = "SELECT * FROM decesos WHERE no_id ='" & TextBox1.Text & "'"

        ds.Reset()
        connect()
        dr.Close()

        sda.SelectCommand = cmd
        sda.Fill(ds)
        DataGridView1.DataSource = ds.Tables(0)

        'Dim search7 As String
        'Dim list7 As Byte
        'If TextBox1.Text <> "" Then
        'search7 = "select no_de_id, fecha, edad from decesos where no_de_id ='" & TextBox1.Text & "'"
        'adapter7 = New OleDbDataAdapter(search7, connection7)
        'find7 = New DataSet
        'adapter7.Fill(find7, "decesos")
        'list7 = find7.Tables("decesos").Rows.Count
        'If list7 <> 0 Then
        'TextBox1.Text = find7.Tables("decesos").Rows(0).Item("no_de_id")
        'TextBox2.Text = find7.Tables("decesos").Rows(0).Item("fecha")
        'TextBox3.Text = find7.Tables("decesos").Rows(0).Item("edad")
        'DataGridView1.DataSource = find7.Tables(0)
        'Else
        MsgBox("EL REGISTRO NO EXISTE EN LA BASE DE DATOS", vbCritical, "ATENCION!")
        'End If
        'End If
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Me.Close()
    End Sub

    Private Sub TextBox1_KeyPress(sender As Object, e As KeyPressEventArgs) Handles TextBox1.KeyPress
        If (Char.IsLetter(e.KeyChar)) Then
            e.Handled = True
        ElseIf (Char.IsSymbol(e.KeyChar)) Then
            e.Handled = True
        ElseIf (Char.IsPunctuation(e.KeyChar)) Then
            e.Handled = True
        ElseIf (Char.IsNumber(e.KeyChar)) Then
            e.Handled = False
            TextBox1.MaxLength = 10
        ElseIf Asc(e.KeyChar) = 13 Then
            TextBox2.Focus()
        End If
    End Sub

    Private Sub TextBox2_KeyPress(sender As Object, e As KeyPressEventArgs) Handles TextBox2.KeyPress
        If (Char.IsLetter(e.KeyChar)) Then
            e.Handled = True
        ElseIf (Char.IsSymbol(e.KeyChar)) Then
            e.Handled = False
        ElseIf (Char.IsPunctuation(e.KeyChar)) Then
            e.Handled = False
        ElseIf (Char.IsNumber(e.KeyChar)) Then
            e.Handled = False
            TextBox1.MaxLength = 10
        ElseIf Asc(e.KeyChar) = 13 Then
            TextBox3.Focus()
        End If
    End Sub

    Private Sub TextBox3_KeyPress(sender As Object, e As KeyPressEventArgs) Handles TextBox3.KeyPress
        If (Char.IsLetter(e.KeyChar)) Then
            e.Handled = True
        ElseIf (Char.IsSymbol(e.KeyChar)) Then
            e.Handled = True
        ElseIf (Char.IsPunctuation(e.KeyChar)) Then
            e.Handled = True
        ElseIf (Char.IsNumber(e.KeyChar)) Then
            e.Handled = False
            TextBox1.MaxLength = 4
        ElseIf Asc(e.KeyChar) = 13 Then
            TextBox2.Focus()
        End If
    End Sub
End Class
﻿Imports System.Data
Imports System.Data.OleDb
Imports System.IO
Public Class nacimientos_altas
    Dim connection1 As New OleDb.OleDbConnection
    Dim command1 As New OleDb.OleDbCommand
    Dim adapter1 As New OleDbDataAdapter
    Dim find1 As New DataSet
    Dim dset1 As New DataSet
    Private Sub nacimientos_altas_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        conn.ConnectionString = "server=localhost;user id=root;port=3306;password=;database=ganadera"
        'Try
        'connection1.ConnectionString = ("Provider=Microsoft.ACE.OLEDB.12.0; Data Source=" & Application.StartupPath & "\ganadera.accdb")
        'connection1.Open()
        'MsgBox("conexion exitosa", vbInformation, "conectado")
        'Catch ex As Exception
        'MsgBox("error al conectar", vbInformation, "error" & ex.Message)
        'End Try
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click

        sql = "INSERT INTO nacimientos VALUES(@no_nacimiento, @fecha, @sexo, @raza);"

        With cmd
            .Parameters.Clear()
            .Parameters.AddWithValue("@no_nacimiento", TextBox3.Text)
            .Parameters.AddWithValue("@fecha", TextBox1.Text)
            .Parameters.AddWithValue("@sexo", ComboBox1.Text)
            .Parameters.AddWithValue("@raza", TextBox2.Text)
        End With

        connect()

        conn.Close()

        '        Try
        '       command1 = New OleDb.OleDbCommand
        '      command1.Connection = connection1
        '
        '   command1.ExecuteNonQuery()
        '  MsgBox("REGISTRO GUARDADO", vbInformation, "CORRECTO")
        ' Catch ex As Exception
        'MsgBox("error de conexion" & ex.Message)
        'End Try
        TextBox1.Text = ""
        TextBox2.Text = ""
        ComboBox1.Text = ""
        TextBox3.Text = ""
        TextBox1.Focus()
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Me.Close()

    End Sub

    Private Sub TextBox1_KeyPress(sender As Object, e As KeyPressEventArgs) Handles TextBox1.KeyPress
        If (Char.IsLetter(e.KeyChar)) Then
            e.Handled = True
        ElseIf (Char.IsSymbol(e.KeyChar)) Then
            e.Handled = False
        ElseIf (Char.IsPunctuation(e.KeyChar)) Then
            e.Handled = False
        ElseIf (Char.IsNumber(e.KeyChar)) Then
            e.Handled = False
            TextBox1.MaxLength = 10
        ElseIf Asc(e.KeyChar) = 13 Then
            TextBox2.Focus()
        End If
    End Sub

    Private Sub TextBox2_KeyPress(sender As Object, e As KeyPressEventArgs) Handles TextBox2.KeyPress
        If (Char.IsLetter(e.KeyChar)) Then
            e.Handled = False
            TextBox1.MaxLength = 10
        ElseIf (Char.IsSymbol(e.KeyChar)) Then
            e.Handled = True
        ElseIf (Char.IsPunctuation(e.KeyChar)) Then
            e.Handled = True
        ElseIf (Char.IsNumber(e.KeyChar)) Then
            e.Handled = True
        ElseIf Asc(e.KeyChar) = 13 Then
            TextBox3.Focus()
        End If
    End Sub

    Private Sub TextBox3_KeyPress(sender As Object, e As KeyPressEventArgs) Handles TextBox3.KeyPress
        If (Char.IsLetter(e.KeyChar)) Then
            e.Handled = True
        ElseIf (Char.IsSymbol(e.KeyChar)) Then
            e.Handled = True
        ElseIf (Char.IsPunctuation(e.KeyChar)) Then
            e.Handled = True
        ElseIf (Char.IsNumber(e.KeyChar)) Then
            e.Handled = False
            TextBox1.MaxLength = 6
        ElseIf Asc(e.KeyChar) = 13 Then
            TextBox1.Focus()
        End If
    End Sub
End Class
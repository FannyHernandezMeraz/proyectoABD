﻿Imports System.Data
Imports System.Data.OleDb
Imports System.IO
Public Class suplementos_bajas
    Dim connection14 As New OleDb.OleDbConnection
    Dim command14 As New OleDb.OleDbCommand
    Dim adapter14 As New OleDbDataAdapter
    Dim find14 As New DataSet
    Dim dset14 As New DataSet
    Private Sub suplementos_bajas_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        conn.ConnectionString = "server=localhost;user id=root;port=3306;password=;database=ganadera"
        '  Try
        'connection14.ConnectionString = ("Provider=Microsoft.ACE.OLEDB.12.0; Data Source=" & Application.StartupPath & "\ganadera.accdb")
        'connection14.Open()
        'MsgBox("conexion exitosa", vbInformation, "conectado")
        'Catch ex As Exception
        'MsgBox("error al conectar", vbInformation, "error" & ex.Message)
        'End Try
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        'Dim delete14 As String
        Dim si14 As Byte
        si14 = MsgBox("EL REGISTRO SE BORRARA DE LA BASE DE DATOS ESTAS SEGURO??", vbYesNo, "??")
        If si14 = vbYes Then
            sql = "DELETE * FROM suplementos WHERE nombre ='" & TextBox1.Text & "'"
            'command14 = New OleDbCommand(delete14, connection14)
            'command14.ExecuteNonQuery()
            With cmd
                .ExecuteNonQuery()
            End With
            connect()
            conn.Close()

            MsgBox("REGISTRO ELIMINADO", vbInformation)
            TextBox1.Text = ""
            ComboBox1.Text = ""
            TextBox3.Text = ""
            TextBox1.Focus()
        Else
            MsgBox("EL REGISTRO NO FUE ELIMINADO", vbInformation)
        End If
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Me.Close()
    End Sub

    Private Sub TextBox1_KeyPress(sender As Object, e As KeyPressEventArgs) Handles TextBox1.KeyPress
        If (Char.IsLetter(e.KeyChar)) Then
            e.Handled = False
            TextBox1.MaxLength = 15
        ElseIf (Char.IsSymbol(e.KeyChar)) Then
            e.Handled = True
        ElseIf (Char.IsPunctuation(e.KeyChar)) Then
            e.Handled = True
        ElseIf (Char.IsNumber(e.KeyChar)) Then
            e.Handled = True
        ElseIf Asc(e.KeyChar) = 13 Then
            TextBox3.Focus()
        End If
    End Sub

    Private Sub TextBox3_KeyPress(sender As Object, e As KeyPressEventArgs) Handles TextBox3.KeyPress
        If (Char.IsLetter(e.KeyChar)) Then
            e.Handled = True
        ElseIf (Char.IsSymbol(e.KeyChar)) Then
            e.Handled = True
        ElseIf (Char.IsPunctuation(e.KeyChar)) Then
            e.Handled = True
        ElseIf (Char.IsNumber(e.KeyChar)) Then
            e.Handled = False
            TextBox1.MaxLength = 4
        ElseIf Asc(e.KeyChar) = 13 Then
            TextBox1.Focus()
        End If
    End Sub
End Class
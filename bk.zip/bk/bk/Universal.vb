﻿Imports MySql.Data.MySqlClient
Module Universal

    Public conn As MySqlConnection = New MySqlConnection
    Public ds As New DataSet
    Public cmd As MySqlCommand = New MySqlCommand
    Public dr As MySqlDataReader
    Public sda As New MySqlDataAdapter
    Public sql As String

    Public Sub connect()
        cmd.CommandText = sql
        cmd.CommandType = CommandType.Text
        cmd.Connection = conn
        conn.Open()
        dr = cmd.ExecuteReader

    End Sub

End Module

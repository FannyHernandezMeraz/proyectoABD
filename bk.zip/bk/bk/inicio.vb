﻿Public Class inicio

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click

        sql = "SELECT * FROM usuarios WHERE nombre_usuario = '" & usuarioTxt.Text & "' AND password = '" & passwordTxt.Text & "' "
        connect()

        If dr.Read Then 'usuarioTxt.Text = "saul" And passwordTxt.Text = "191272" Then
            MsgBox("Sesion exitosa", vbInformation, "bienvenido")
            Me.Hide()
            menu_.Show()
        Else
            MsgBox("información de acceso incorrecta", vbCritical, "intente de nuevo")
            usuarioTxt.Text = Nothing
            passwordTxt.Text = Nothing
            usuarioTxt.Focus()
        End If

        conn.Close()
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        Me.Close()
    End Sub

    Private Sub usuarioTxt_KeyPress(sender As Object, e As KeyPressEventArgs) Handles usuarioTxt.KeyPress
        'If (Char.IsLetter(e.KeyChar)) Then
        'e.Handled = False
        'usuarioTxt.MaxLength = 4
        'ElseIf (Char.IsSymbol(e.KeyChar)) Then
        'e.Handled = True
        'ElseIf (Char.IsPunctuation(e.KeyChar)) Then
        'e.Handled = True
        'ElseIf (Char.IsNumber(e.KeyChar)) Then
        'e.Handled = True
        'ElseIf Asc(e.KeyChar) = 13 Then
        'passwordTxt.Focus()
        'End If
    End Sub

    Private Sub passwordTxt_KeyPress(sender As Object, e As KeyPressEventArgs) Handles passwordTxt.KeyPress
        'If (Char.IsLetter(e.KeyChar)) Then
        'e.Handled = True
        'ElseIf (Char.IsSymbol(e.KeyChar)) Then
        'e.Handled = True
        'ElseIf (Char.IsPunctuation(e.KeyChar)) Then
        'e.Handled = True
        'ElseIf (Char.IsNumber(e.KeyChar)) Then
        'e.Handled = False
        'usuarioTxt.MaxLength = 6
        'ElseIf Asc(e.KeyChar) = 13 Then
        'passwordTxt.Focus()
        'End If
    End Sub

    Private Sub inicio_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        conn.ConnectionString = "server=localhost;user id=root;port=3306;password=;database=ganadera"
    End Sub
End Class
﻿Public Class menu_

    Private Sub AltasToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles AltasToolStripMenuItem.Click
        nacimientos_altas.Show()
    End Sub

    Private Sub BajasToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles BajasToolStripMenuItem.Click
        nacimientos_bajas.Show()
    End Sub

    Private Sub ConsultasToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ConsultasToolStripMenuItem.Click
        nacimientos_consultas.Show()
    End Sub

    Private Sub ModificacionesToolStripMenuItem_Click(sender As Object, e As EventArgs)
        nacimientos_modificaciones.Show()
    End Sub

    Private Sub AltasToolStripMenuItem1_Click(sender As Object, e As EventArgs) Handles AltasToolStripMenuItem1.Click
        decesos_altas.Show()
    End Sub

    Private Sub BajasToolStripMenuItem1_Click(sender As Object, e As EventArgs) Handles BajasToolStripMenuItem1.Click
        decesos_bajas.Show()
    End Sub

    Private Sub ConsultasToolStripMenuItem1_Click(sender As Object, e As EventArgs) Handles ConsultasToolStripMenuItem1.Click
        decesos_consultas.Show()
    End Sub

    Private Sub ModificacionesToolStripMenuItem1_Click(sender As Object, e As EventArgs)
        decesos_modificaciones.Show()
    End Sub

    Private Sub AltasToolStripMenuItem2_Click(sender As Object, e As EventArgs) Handles AltasToolStripMenuItem2.Click
        ventas_altas.Show()
    End Sub

    Private Sub BajasToolStripMenuItem2_Click(sender As Object, e As EventArgs) Handles BajasToolStripMenuItem2.Click
        ventas_bajas.Show()
    End Sub

    Private Sub ConsultasToolStripMenuItem2_Click(sender As Object, e As EventArgs) Handles ConsultasToolStripMenuItem2.Click
        ventas_consultas.Show()
    End Sub

    Private Sub ModificacionesToolStripMenuItem2_Click(sender As Object, e As EventArgs)
        ventas_modificaciones.Show()
    End Sub

    Private Sub AltasToolStripMenuItem3_Click(sender As Object, e As EventArgs) Handles AltasToolStripMenuItem3.Click
        suplementos_altas.Show()
    End Sub

    Private Sub BajasToolStripMenuItem3_Click(sender As Object, e As EventArgs) Handles BajasToolStripMenuItem3.Click
        suplementos_bajas.Show()
    End Sub

    Private Sub ConsultasToolStripMenuItem3_Click(sender As Object, e As EventArgs) Handles ConsultasToolStripMenuItem3.Click
        suplementos_consultas.Show()
    End Sub

    Private Sub ModificacionesToolStripMenuItem3_Click(sender As Object, e As EventArgs)
        suplementos_modificaciones.Show()
    End Sub

    Private Sub AltasToolStripMenuItem4_Click(sender As Object, e As EventArgs)
        ganado_altas.Show()
    End Sub

    Private Sub BajasToolStripMenuItem4_Click(sender As Object, e As EventArgs)
        ganado_bajas.Show()
    End Sub

    Private Sub ConsultasToolStripMenuItem4_Click(sender As Object, e As EventArgs)
        ganado_consultas.Show()
    End Sub

    Private Sub ModificacionesToolStripMenuItem4_Click(sender As Object, e As EventArgs)
        ganado_modificaciones.Show()
    End Sub

    Private Sub SalirToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles SalirToolStripMenuItem.Click
        Me.Close()
    End Sub

    Private Sub menu__Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class
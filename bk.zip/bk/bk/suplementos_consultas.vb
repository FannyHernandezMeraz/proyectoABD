﻿Imports System.Data
Imports System.Data.OleDb
Imports System.IO
Public Class suplementos_consultas
    Dim connection15 As New OleDb.OleDbConnection
    Dim command15 As New OleDb.OleDbCommand
    Dim adapter15 As New OleDbDataAdapter
    Dim find15 As New DataSet
    Dim dset15 As New DataSet
    Private Sub suplementos_consultas_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        conn.ConnectionString = "server=localhost;user id=root;port=3306;password=;database=ganadera"
        'Try
        ' connection15.ConnectionString = ("Provider=Microsoft.ACE.OLEDB.12.0; Data Source=" & Application.StartupPath & "\ganadera.accdb")
        'connection15.Open()
        'MsgBox("conexion exitosa", vbInformation, "conectado")
        'Catch ex As Exception
        'MsgBox("error al conectar", vbInformation, "error" & ex.Message)
        'End Try
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click

        sql = "SELECT * FROM suplementos WHERE nombre ='" & TextBox1.Text & "'"

        ds.Reset()
        connect()
        dr.Close()

        sda.SelectCommand = cmd
        sda.Fill(ds)
        DataGridView1.DataSource = ds.Tables(0)

        'Dim search15 As String
        'Dim list15 As Byte
        'If TextBox1.Text <> "" Then
        'search15 = "select nombre, tipo, cantidad from suplementos where nombre ='" & TextBox1.Text & "'"
        'adapter15 = New OleDbDataAdapter(search15, connection15)
        'find15 = New DataSet
        'adapter15.Fill(find15, "suplementos")
        'list15 = find15.Tables("suplementos").Rows.Count
        'If list15 <> 0 Then
        'TextBox1.Text = find15.Tables("suplementos").Rows(0).Item("numero")
        'ComboBox1.Text = find15.Tables("suplementos").Rows(0).Item("sexo")
        'TextBox3.Text = find15.Tables("suplementos").Rows(0).Item("peso")
        'DataGridView1.DataSource = find15.Tables(0)
        'Else
        MsgBox("EL REGISTRO NO EXISTE EN LA BASE DE DATOS", vbCritical, "ATENCION!")
        'End If
        'End If
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Me.Close()
    End Sub

    Private Sub TextBox1_KeyPress(sender As Object, e As KeyPressEventArgs) Handles TextBox1.KeyPress
        If (Char.IsLetter(e.KeyChar)) Then
            e.Handled = False
            TextBox1.MaxLength = 15
        ElseIf (Char.IsSymbol(e.KeyChar)) Then
            e.Handled = True
        ElseIf (Char.IsPunctuation(e.KeyChar)) Then
            e.Handled = True
        ElseIf (Char.IsNumber(e.KeyChar)) Then
            e.Handled = True
        ElseIf Asc(e.KeyChar) = 13 Then
            TextBox3.Focus()
        End If
    End Sub

    Private Sub TextBox3_KeyPress(sender As Object, e As KeyPressEventArgs) Handles TextBox3.KeyPress
        If (Char.IsLetter(e.KeyChar)) Then
            e.Handled = True
        ElseIf (Char.IsSymbol(e.KeyChar)) Then
            e.Handled = True
        ElseIf (Char.IsPunctuation(e.KeyChar)) Then
            e.Handled = True
        ElseIf (Char.IsNumber(e.KeyChar)) Then
            e.Handled = False
            TextBox1.MaxLength = 4
        ElseIf Asc(e.KeyChar) = 13 Then
            TextBox1.Focus()
        End If
    End Sub
End Class
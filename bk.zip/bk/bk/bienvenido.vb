﻿Public Class bienvenido
    Public t As Integer
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ProgressBar1.Value = 0.0
        ProgressBar1.Maximum = 100
        Timer1.Enabled = True
        Timer1.Interval = 50
    End Sub

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        If t < 100 Then
            ProgressBar1.Value = t
            t = t + 1
            Label1.text = t
        Else
            Timer1.Enabled = False
            Me.Hide()
            inicio.show()
        End If
    End Sub
End Class
